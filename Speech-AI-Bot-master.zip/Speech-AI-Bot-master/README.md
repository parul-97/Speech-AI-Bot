# Speech-AI-Bot
https://speech-ai-bot.herokuapp.com/
Simple Speech AI Bot using Web Speech API- API.AI

Create a new file, .env in the root folder and put APIAI_TOKEN = "Your Client key of APIAI"(without quotes) and APIAI_SESSION_ID = "any arbitrary string"(without quotes).

